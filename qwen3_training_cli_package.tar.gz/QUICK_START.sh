#!/bin/bash

echo "🚀 AI Training CLI - Quick Start"
echo "==============================="
echo ""
echo "This will set up everything and start training a Python code assistant."
echo ""
read -p "Continue? [y/N]: " confirm

if [[ $confirm =~ ^[Yy]$ ]]; then
    echo "🔧 Running setup..."
    chmod +x runpod_setup_script.sh
    ./runpod_setup_script.sh
else
    echo "❌ Setup cancelled. Run './runpod_setup_script.sh' when ready."
fi
